#!/bin/bash
#sudo umount -a -t -l
#sudo mount -t smbfs -o username=leif,password=1q2w3e4r //WIN-55FSM725G9H/share /home/leif/mnt/share
sudo mount -t smbfs -o username=leif,password=1q2w3e4r //WINVMWARE/share /home/leif/mnt/share
