#!/bin/bash

tail -f $CATALINA_HOME/logs/catalina.out
