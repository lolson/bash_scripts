#!/bin/bash

/home/leif/netbeans-7.3.1/bin/netbeans --jdkhome $JAVA_HOME
