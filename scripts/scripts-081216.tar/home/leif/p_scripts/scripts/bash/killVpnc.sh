#!/bin/bash

pgrep vpnc | sudo xargs kill
