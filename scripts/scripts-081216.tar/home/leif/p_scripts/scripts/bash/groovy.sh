#!/bin/bash
unset CLASSPATH
groovyConsole
