#!/bin/bash

cd $CATALINA_HOME/bin
pwd
$CATALINA_HOME/bin/startup.sh
ps -elf
