# Usage: java LDAPClient <userDN> <password>
java LDAPClient uid=admin,ou=system secret ou=people,dc=emergent,dc=com
#java LDAPClient uid=admin,ou=system secret ou=people
