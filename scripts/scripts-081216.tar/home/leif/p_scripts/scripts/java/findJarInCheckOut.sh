#!/bin/bash
./findClassInJars.sh $GSCC_HOME $1
