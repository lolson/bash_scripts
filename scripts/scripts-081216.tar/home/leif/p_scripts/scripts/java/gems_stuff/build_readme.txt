This build file contains run and debug targets for a display
test frame.  Its a simple display viewer panel for testing
out single displays. See the source file TestDisplayFrame.java 
