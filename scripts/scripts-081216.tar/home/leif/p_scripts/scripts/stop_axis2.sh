#!/bin/bash
export TOMCAT_HOME=/opt/apache-tomcat-7.0.28
export CATALINA_HOME=$TOMCAT_HOME
$CATALINA_HOME/bin/shutdown.sh

