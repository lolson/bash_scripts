use feature say;
say "The file 'memo1' exists and is readable." if (-r "memo1");
