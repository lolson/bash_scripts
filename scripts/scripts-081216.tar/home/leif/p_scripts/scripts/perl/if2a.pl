print "Enter the word 'five': ";
$entry =<>;
chomp ($entry);
if($entry eq "five") {  # use eq for a string comparison
    print "Thank you for entering 'five'.\n";
}
print "End.\n";


