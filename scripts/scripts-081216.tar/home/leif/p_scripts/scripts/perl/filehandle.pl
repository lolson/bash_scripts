
open(FIZZLE,"> myfilename"); #Create file
open(FIZZLE,">> myfilename"); #Append to file
# @FIZZLE an array indexed by number
# %FIZZLE an array indexed by stirng
# &FIZZLE a subroutine
# *FIZZLE everything named FIZZLE


