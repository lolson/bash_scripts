use feature say;
$name="Sam";
$n1=5; $n2=2;
say "$name $n1 $n2";
say "$n1+$n2";
say '$name $n1 $n2';
say $n1 + $n2, " ", $n1*$n2;
say $name + $n1;
say "$name "+ $n1;
