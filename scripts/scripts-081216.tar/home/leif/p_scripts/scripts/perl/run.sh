#!/bin/bash

#perl soap_trans.pl FIN/soap_project.xml
#perl soap_trans1.pl FIN/soap_project.xml
#perl soap_trans1.pl FIN/ex1.txt
#perl trans_soap.pl FIN/ex1.txt
#perl trans_soap.pl FIN/soap_project.xml
perl trans_soap.pl FIN/JMS-SP5-Demo-soapui-project-ver1.xml
