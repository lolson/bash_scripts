use strict;
my $name = 'Sam';
print "Hello, $nam, how are you?\n";
