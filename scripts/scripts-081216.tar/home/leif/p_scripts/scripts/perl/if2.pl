print "Enter 28:
"; $entry =<>;
if ($entry == 28) { #Use == for a numeric comparison
    print "Thank you for entering 28.\n";
}
print "End.\n";

