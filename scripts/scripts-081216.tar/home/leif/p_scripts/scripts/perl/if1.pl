use feature say;
if(-r "memo1"){
    say "The file 'memo1' exists and is readable.";
}
