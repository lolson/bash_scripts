print "Any\n $1"
