# print the files given as cmd ln args
while ($_ = <ARGV>) {
    print $_;
}
