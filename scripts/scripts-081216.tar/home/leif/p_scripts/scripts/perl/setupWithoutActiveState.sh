# remove ActiveState from the PATH
export PATH=.:/home/leif/netbeans-7.3.1/bin:/home/leif/opt/netbeans-7.3.1/java/ant/bin:/opt/jdk1.7.0_25/bin:/bin:/home/leif/scripts:/usr/lib/lightdm/lightdm:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games
