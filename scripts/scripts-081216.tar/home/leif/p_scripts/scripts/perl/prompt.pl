#Some Header

print "enter hexadecimal: ";
$answer = <STDIN>;
print hex($answer),"\n";
$pet = 'dog';
$sign = "Beware of $pet\n";
print $sign;
