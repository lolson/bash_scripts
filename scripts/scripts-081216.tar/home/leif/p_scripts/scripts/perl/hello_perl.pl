#print "Hello, Perl!\n"
use feature ':5.10';
say "Hello, Perl ver 5.12!";
