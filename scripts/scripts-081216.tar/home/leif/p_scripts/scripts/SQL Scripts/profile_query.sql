select * from profile
where device_id = '93026410';