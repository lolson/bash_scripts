delete from tblapproval;
delete from tblfirmware_upgrade_group;
delete from tblfirmware_upgrade;
delete from tblversion;
delete from tblproduct_component;