#!/bin/bash
rdesktop -g 1280x1024 192.168.10.68
# sets the resolution with -g option
