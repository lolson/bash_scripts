#!/bin/bash
ssh -X centos@cofesb1
