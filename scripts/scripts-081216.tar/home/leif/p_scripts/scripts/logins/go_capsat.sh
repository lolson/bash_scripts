#!/bin/bash
ssh -X capsat@capsatvm
