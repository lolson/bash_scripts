#!/bin/bash
ssh -X hypervisor@hypervisor
