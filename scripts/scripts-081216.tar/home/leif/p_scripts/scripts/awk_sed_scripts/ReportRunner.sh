#!/bin/bash

java -jar ../lib/report-runner.jar %1 %2 %3

exit 0
