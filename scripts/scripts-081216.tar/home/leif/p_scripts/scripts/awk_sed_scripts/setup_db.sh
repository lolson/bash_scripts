./ant/bin/ant setup_datasource > setup_db.log
