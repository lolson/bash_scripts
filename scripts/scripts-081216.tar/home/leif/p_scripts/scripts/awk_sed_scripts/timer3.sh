#!/bin/bash
# get the current hour
HOUR=`date +%H`
MIN=`date +%M`
echo "Hour is $HOUR"
echo "and minute is $MIN"
