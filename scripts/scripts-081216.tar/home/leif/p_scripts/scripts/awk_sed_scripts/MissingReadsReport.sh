#!/bin/bash

./ReportRunner.sh CSV MISSING_READS_REPORT