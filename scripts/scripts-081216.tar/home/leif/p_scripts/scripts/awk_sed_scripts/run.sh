#!/bin/bash
./runner.sh CSV MISSING_READS_REPORT
