#!/bin/bash
echo -n "How old are you? "
read age
echo "Wow, in $((60-age)), you'll be 60!"
echo There are $((60*60*24*365)) secconds in a non-leap year!
