#!/bin/bash
export PATH=$PATH:/home/leif/git_repo/Dropbox-Uploader
KEEPASSX_KDB=~/Documents/psafe/keepassx_20151202.kdb
#/home/leif/git_repo/Dropbox-Uploader/dropbox_uploader.sh -k upload ~/Documents/psafe/keepassx.kdb keepass-`date '+%m%d%y'`.kdb
/home/leif/opt/git_repo/Dropbox-Uploader/dropbox_uploader.sh -k upload ~/Documents/psafe/keepassx_20151202.kdb keepass-`date '+%m%d%y'`.kdb
