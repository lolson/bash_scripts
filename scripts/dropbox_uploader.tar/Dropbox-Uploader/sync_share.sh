#!/bin/bash
export PATH=$PATH:/home/leif/git_repo/Dropbox-Uploader
MIN=30
SRC=~/Documents/dropbox_share

~/scripts/bash/move_dld_2share.sh
find $SRC -mmin -$MIN -type f -print0 | while IFS= read -r -d $'\0' line; do
    echo "$line"
    /home/leif/opt/git_repo/Dropbox-Uploader/dropbox_uploader.sh -k upload $line share
done
